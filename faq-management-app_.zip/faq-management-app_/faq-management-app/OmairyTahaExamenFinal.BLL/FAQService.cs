﻿using OmairyTahaExamenFinal.DAL;
using OmairyTahaExamenFinal.Models;


namespace OmairyTahaExamenFinal.BLL
{
    public class FAQService
    {
        private readonly FAQRepository _repository;

        public FAQService()
        {
            _repository = new FAQRepository();
        }

        // Récupérer toutes les FAQs
        public List<FAQItem> GetAllFAQs()
        {
            // TODO: Appelez la méthode GetAll du repository
            return _repository.GetAll();
        }

        // Rechercher des FAQs
        public List<FAQItem> SearchFAQs(string keyword)
        {
            // TODO: Validez que keyword n'est pas vide
            if (string.IsNullOrWhiteSpace(keyword))
                throw new ArgumentException("Le mot-clé ne peut pas être vide.");

            return _repository.Search(keyword);
        }

        // Obtenir les FAQs par catégorie
        public List<FAQItem> GetFAQsByCategory(string category)
        {
            // TODO: Si category est vide, retournez ________
            // Sinon, appelez repository.____________________
            if (string.IsNullOrWhiteSpace(category))
                return GetAllFAQs();

            return _repository.GetByCategory(category);
        }

        // Ajouter une FAQ
        public bool AddFAQ(string question, string answer, string category)
        {
            // TODO: Validez les paramètres
            if (string.IsNullOrWhiteSpace(question)) return false;
            if (string.IsNullOrWhiteSpace(answer)) return false;

            // TODO: Créez un nouvel objet FAQItem
            var faq = new FAQItem
            {
                Question = question.Trim(),
                Answer = answer.Trim(),
                Category = string.IsNullOrWhiteSpace(category) ? "Général" : category.Trim(),
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            // TODO: Ajoutez avec try-catch
            try
            {
                _repository.Add(faq);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Supprimer une FAQ
        public bool DeleteFAQ(int id)
        {
            // TODO: Appelez repository.Delete() dans un try-catch
            // Retournez true si succès, false si échec
            try
            {
                _repository.Delete(id);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Obtenir toutes les catégories
        public List<string> GetAllCategories()
        {
            // TODO: Appelez repository.____________________
            return _repository.GetCategories();
        }

        // Obtenir le nombre total de FAQs
        public int GetTotalFAQCount()
        {
            // TODO: Retournez le Count() de
            return _repository.GetAll().Count;
        }

        // Statistiques par catégorie
        public Dictionary<string, int> GetFAQCountByCategory()
        {
            // TODO: Utilisez LINQ GroupBy pour compter par catégorie
            return _repository.GetAll()
                .GroupBy(f => string.IsNullOrWhiteSpace(f.Category) ? "Sans catégorie" : f.Category)
                .ToDictionary(g => g.Key, g => g.Count());
        }
    }
}

