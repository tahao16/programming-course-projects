# FAQ Management Desktop App

A Windows Forms desktop application for managing frequently asked questions (FAQs), built with C#, Entity Framework Core, and SQL Server LocalDB.

## Technologies
- C# and Windows Forms
- Entity Framework Core 10
- SQL Server LocalDB
- Layered project structure: UI, business logic, data access, and models

## Features visible in the source
- Display and manage FAQ items
- Add FAQ items through a Windows Forms interface
- Separate service and repository layers
- Entity Framework Core data model with sample FAQ seed data

## Project structure
- `OmairyTahaExamenFinal.UI` — Windows Forms user interface
- `OmairyTahaExamenFinal.BLL` — FAQ service/business logic
- `OmairyTahaExamenFinal.DAL` — Entity Framework context and repository
- `OmairyTahaExamenFinal.Models` — FAQ item model

## Requirements
- Windows
- Visual Studio with the .NET desktop development workload
- .NET 10 SDK
- SQL Server LocalDB

## Run
1. Open `OmairyTahaExamenFinal.slnx` in a compatible recent version of Visual Studio.
2. Restore NuGet packages.
3. Confirm SQL Server LocalDB is installed and available. The current context uses a local database named `OmairyTahadb`.
4. Set `OmairyTahaExamenFinal.UI` as the startup project and run.

## Notes
This repository is based on a student project. The included LocalDB connection string is intended for a local development environment, not a production database. Review database setup and migrations before running on a new machine.
