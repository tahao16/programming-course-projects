﻿using System.ComponentModel.DataAnnotations;

namespace OmairyTahaExamenFinal.Models
{
    public class FAQItem
    {
        // TODO: Ajoutez l'attribut [Key]
        [Key]
        public int Id { get; set; }

        // TODO: Ajoutez les attributs [Required] et [MaxLength(300)]
        [Required]
        [MaxLength(300)]
        public string Question { get; set; }

        // TODO: Ajoutez les attributs [Required] et [MaxLength(1500)]
        [Required]
        [MaxLength(1500)]
        public string Answer { get; set; }

        // TODO: Ajoutez l'attribut [MaxLength(50)]
        [MaxLength(50)]
        public string Category { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; }
    }
}

