﻿using Microsoft.EntityFrameworkCore;
using OmairyTahaExamenFinal.Models;


namespace OmairyTahaExamenFinal.DAL
{
    public class FAQRepository
    {
        private readonly FAQContext _context;

        public FAQRepository()
        {
            _context = new FAQContext();
            _context.Database.EnsureCreated();
        }

        // CREATE
        public void Add(FAQItem faq)
        {
            // TODO: Ajoutez la FAQ au contexte et sauvegardez
            _context.FAQItems.Add(faq);
            _context.SaveChanges();
        }

        // READ - All
        public List<FAQItem> GetAll()
        {
            // TODO: Retournez toutes les FAQs actives (IsActive = true)
            return _context.FAQItems
                .Where(f => f.IsActive)
                .OrderByDescending(f => f.CreatedDate)
                .ToList();
        }

        // READ - By Id
        public FAQItem GetById(int id)
        {
            // TODO: Retournez la FAQ avec l'Id spécifié (si IsActive = true)
            return _context.FAQItems
                .FirstOrDefault(f => f.Id == id && f.IsActive);
        }

        // READ - Search
        public List<FAQItem> Search(string keyword)
        {
            // TODO: Recherchez dans Question et Answer avec Contains
            if (string.IsNullOrWhiteSpace(keyword))
                return GetAll();

            keyword = keyword.Trim();

            return _context.FAQItems
                .Where(f => f.IsActive &&
                            (f.Question.Contains(keyword) || f.Answer.Contains(keyword)))
                .OrderByDescending(f => f.CreatedDate)
                .ToList();
        }

        // READ - By Category
        public List<FAQItem> GetByCategory(string category)
        {
            // TODO
            if (string.IsNullOrWhiteSpace(category))
                return GetAll();

            category = category.Trim();

            return _context.FAQItems
                .Where(f => f.IsActive && f.Category == category)
                .OrderByDescending(f => f.CreatedDate)
                .ToList();
        }

        // UPDATE
        public void Update(FAQItem faq)
        {
            // TODO: Mettez à jour l'entité
            _context.FAQItems.Update(faq);
            _context.SaveChanges();
        }

        // DELETE (Soft Delete)
        public void Delete(int id)
        {
            // TODO: Soft delete => IsActive = false
            var existing = _context.FAQItems.FirstOrDefault(f => f.Id == id && f.IsActive);
            if (existing != null)
            {
                existing.IsActive = false;
                _context.SaveChanges();
            }
        }

        // Get Categories
        public List<string> GetCategories()
        {
            // TODO: Retournez la liste distincte des catégories
            return _context.FAQItems
                .Where(f => f.IsActive && !string.IsNullOrEmpty(f.Category))
                .Select(f => f.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToList();
        }
    }
}

