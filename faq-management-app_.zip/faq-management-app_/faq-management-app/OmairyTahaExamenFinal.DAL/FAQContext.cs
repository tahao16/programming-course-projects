﻿
using Microsoft.EntityFrameworkCore;
using OmairyTahaExamenFinal.Models;

namespace OmairyTahaExamenFinal.DAL
{
    public class FAQContext : DbContext
    {
        // DbSet configuré
        public DbSet<FAQItem> FAQItems { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Connexion SQL Server LocalDB
                optionsBuilder.UseSqlServer(
                    @"Server=(localdb)\MSSQLLocalDB;Database=OmairyTahadb;Trusted_Connection=True;"

                );
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Données initiales (seed data)
            modelBuilder.Entity<FAQItem>().HasData(
                new FAQItem
                {
                    Id = 1,
                    Question = "Comment créer un compte ?",
                    Answer = "Cliquez sur le bouton Inscription et remplissez le formulaire.",
                    Category = "Compte",
                    CreatedDate = new DateTime(2025, 10, 1),
                    IsActive = true
                },
                new FAQItem
                {
                    Id = 2,
                    Question = "Comment modifier mon mot de passe ?",
                    Answer = "Allez dans les paramètres de votre compte.",
                    Category = "Compte",
                    CreatedDate = new DateTime(2025, 10, 2),
                    IsActive = true
                },
                new FAQItem
                {
                    Id = 3,
                    Question = "Qui contacter en cas de problème ?",
                    Answer = "Contactez le service de support technique.",
                    Category = "Support",
                    CreatedDate = new DateTime(2025, 10, 3),
                    IsActive = true
                }
            );
        }
    }
}
