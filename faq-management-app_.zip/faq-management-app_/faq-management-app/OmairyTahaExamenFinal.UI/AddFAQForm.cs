﻿using OmairyTahaExamenFinal.BLL;
using OmairyTahaExamenFinal.Models;


namespace OmairyTahaExamenFinal.UI
{
    public partial class AddFAQForm : Form
    {
        public string Question { get; private set; }
        public string Answer { get; private set; }
        public string Category { get; private set; }

        public AddFAQForm(List<string> categories)
        {
            InitializeComponent();
            LoadCategories(categories);
        }

        private void LoadCategories(List<string> categories)
        {
            // TODO: Chargez les catégories dans le ComboBox
            cmbCategory.Items.Clear();

            if (categories != null)
            {
                foreach (var c in categories.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct())
                    cmbCategory.Items.Add(c);
            }

            if (cmbCategory.Items.Count > 0)
                cmbCategory.SelectedIndex = 0;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // TODO: Validez les champs
            var q = txtQuestion.Text.Trim();
            var a = txtAnswer.Text.Trim();
            var c = cmbCategory.SelectedItem?.ToString();

            if (string.IsNullOrWhiteSpace(q))
            {
                MessageBox.Show("La Question est obligatoire.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtQuestion.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(a))
            {
                MessageBox.Show("La Réponse est obligatoire.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAnswer.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(c))
            {
                MessageBox.Show("La Catégorie est obligatoire.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbCategory.Focus();
                return;
            }

            // Sauvegarder dans les propriétés publiques
            Question = q;
            Answer = a;
            Category = c;

            // Si validation OK → fermer avec OK
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // TODO: Définissez DialogResult = DialogResult.Cancel
            // Fermez le formulaire
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void AddFAQForm_Load(object sender, EventArgs e)
        {

        }
    }
}

