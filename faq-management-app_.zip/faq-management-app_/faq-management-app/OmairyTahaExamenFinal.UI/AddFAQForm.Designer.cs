﻿namespace OmairyTahaExamenFinal.UI
{
    partial class AddFAQForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            label1 = new Label();
            txtQuestion = new TextBox();
            label2 = new Label();
            txtAnswer = new TextBox();
            label3 = new Label();
            cmbCategory = new ComboBox();
            btnSave = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = Color.FromArgb(0, 0, 64);
            label1.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Yellow;
            label1.Location = new Point(20, 20);
            label1.Name = "label1";
            label1.Size = new Size(100, 23);
            label1.TabIndex = 0;
            label1.Text = "Question:";
            // 
            // txtQuestion
            // 
            txtQuestion.Location = new Point(20, 45);
            txtQuestion.Multiline = true;
            txtQuestion.Name = "txtQuestion";
            txtQuestion.Size = new Size(440, 80);
            txtQuestion.TabIndex = 1;
            // 
            // label2
            // 
            label2.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Yellow;
            label2.Location = new Point(20, 140);
            label2.Name = "label2";
            label2.Size = new Size(100, 23);
            label2.TabIndex = 2;
            label2.Text = "Réponse:";
            // 
            // txtAnswer
            // 
            txtAnswer.Location = new Point(20, 165);
            txtAnswer.Multiline = true;
            txtAnswer.Name = "txtAnswer";
            txtAnswer.Size = new Size(440, 120);
            txtAnswer.TabIndex = 3;
            // 
            // label3
            // 
            label3.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Yellow;
            label3.Location = new Point(20, 300);
            label3.Name = "label3";
            label3.Size = new Size(100, 23);
            label3.TabIndex = 4;
            label3.Text = "Catégorie:";
            // 
            // cmbCategory
            // 
            cmbCategory.Location = new Point(126, 294);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(200, 33);
            cmbCategory.TabIndex = 5;
            // 
            // btnSave
            // 
            btnSave.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSave.ForeColor = Color.Yellow;
            btnSave.Location = new Point(72, 340);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(103, 39);
            btnSave.TabIndex = 6;
            btnSave.Text = " Enregistrer\r\n";
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.ForeColor = Color.Yellow;
            btnCancel.Location = new Point(260, 340);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(114, 39);
            btnCancel.TabIndex = 7;
            btnCancel.Text = " Annuler";
            btnCancel.Click += btnCancel_Click;
            // 
            // AddFAQForm
            // 
            BackColor = Color.FromArgb(0, 0, 64);
            ClientSize = new Size(500, 420);
            Controls.Add(label1);
            Controls.Add(txtQuestion);
            Controls.Add(label2);
            Controls.Add(txtAnswer);
            Controls.Add(label3);
            Controls.Add(cmbCategory);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            Name = "AddFAQForm";
            Text = "Ajouter une FAQ";
            Load += AddFAQForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1, label2, label3;
        private TextBox txtQuestion, txtAnswer;
        private ComboBox cmbCategory;
        private Button btnSave, btnCancel;
    }
}
