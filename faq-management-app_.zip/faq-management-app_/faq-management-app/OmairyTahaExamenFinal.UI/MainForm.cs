﻿using OmairyTahaExamenFinal.BLL;
using OmairyTahaExamenFinal.Models;


namespace OmairyTahaExamenFinal.UI
{
    public partial class MainForm : Form
    {
        private FAQService _faqService;

        public MainForm()
        {
            InitializeComponent();
            _faqService = new FAQService();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: Appelez les méthodes d'initialisation
            LoadCategories();
            LoadFAQs();
        }

        private void ConfigureDataGridView()
        {
            // TODO: Configurez le DataGridView après le premier chargement
            // Cachez les colonnes Id et IsActive
            // Renommez les en-têtes (Question, Réponse, Catégorie, Date de création)
            // Formatez la colonne CreatedDate en dd/MM/yyyy

            if (dgvFAQs.Columns.Contains("Id"))
                dgvFAQs.Columns["Id"].Visible = false;

            if (dgvFAQs.Columns.Contains("IsActive"))
                dgvFAQs.Columns["IsActive"].Visible = false;

            if (dgvFAQs.Columns.Contains("Question"))
                dgvFAQs.Columns["Question"].HeaderText = "Question";

            if (dgvFAQs.Columns.Contains("Answer"))
                dgvFAQs.Columns["Answer"].HeaderText = "Réponse";

            if (dgvFAQs.Columns.Contains("Category"))
                dgvFAQs.Columns["Category"].HeaderText = "Catégorie";

            if (dgvFAQs.Columns.Contains("CreatedDate"))
            {
                dgvFAQs.Columns["CreatedDate"].HeaderText = "Date de création";
                dgvFAQs.Columns["CreatedDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }
        }

        private void LoadCategories()
        {
            try
            {
                // TODO: Chargez les catégories dans le ComboBox
                var categories = _faqService.GetAllCategories();

                cmbCategory.Items.Clear();
                cmbCategory.Items.Add("Toutes");

                foreach (var c in categories)
                    cmbCategory.Items.Add(c);

                cmbCategory.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors du chargement des catégories: {ex.Message}");
            }
        }

        private void LoadFAQs()
        {
            try
            {
                // TODO: Chargez toutes les FAQs
                var faqs = _faqService.GetAllFAQs();
                DisplayFAQs(faqs);
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors du chargement des FAQs: {ex.Message}");
            }
        }

        private void DisplayFAQs(List<FAQItem> faqs)
        {
            // TODO: Affichez les FAQs dans le DataGridView
            dgvFAQs.DataSource = null;
            dgvFAQs.DataSource = faqs;

            // TODO: Cachez les colonnes Id et IsActive si elles existent
            ConfigureDataGridView();

            // TODO: Mettez à jour la StatusBar
            UpdateStatusBar(faqs.Count);
        }

        private void UpdateStatusBar(int count)
        {
            // TODO: Mettez à jour lblStatus et lblCount
            lblStatus.Text = $"Total: {count} FAQ(s)";
            lblCount.Text = $"Dernière MAJ: {DateTime.Now:dd/MM/yyyy HH:mm}";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // TODO: Recherchez les FAQs selon le mot-clé dans txtSearch
            try
            {
                var keyword = txtSearch.Text;

                if (string.IsNullOrWhiteSpace(keyword))
                {
                    LoadFAQs();
                    return;
                }

                var results = _faqService.SearchFAQs(keyword);
                DisplayFAQs(results);
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors de la recherche: {ex.Message}");
            }
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            // TODO: Filtrez par catégorie
            try
            {
                var category = cmbCategory.SelectedItem?.ToString();

                if (string.IsNullOrWhiteSpace(category) || category == "Toutes")
                {
                    LoadFAQs();
                    return;
                }

                var list = _faqService.GetFAQsByCategory(category);
                DisplayFAQs(list);
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors du filtrage: {ex.Message}");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // TODO: Ouvrez le formulaire AddFAQForm
            try
            {
                var categories = _faqService.GetAllCategories();
                using var form = new AddFAQForm(categories);

                if (form.ShowDialog() == DialogResult.OK)
                {
                    var ok = _faqService.AddFAQ(form.Question, form.Answer, form.Category);
                    if (!ok)
                        ShowError("Impossible d'ajouter la FAQ.");

                    LoadCategories();
                    LoadFAQs();
                }
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors de l'ajout: {ex.Message}");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // TODO: Supprimez la FAQ sélectionnée
            try
            {
                if (dgvFAQs.CurrentRow?.DataBoundItem is FAQItem selected)
                {
                    var confirm = MessageBox.Show(
                        "Confirmer la suppression ?",
                        "Supprimer",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);

                    if (confirm == DialogResult.Yes)
                    {
                        var ok = _faqService.DeleteFAQ(selected.Id);
                        if (!ok)
                            ShowError("Erreur lors de la suppression.");

                        LoadCategories();
                        LoadFAQs();
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors de la suppression: {ex.Message}");
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            // TODO: Réinitialisez les filtres et rechargez
            try
            {
                txtSearch.Text = "";
                cmbCategory.SelectedIndex = 0;
                LoadCategories();
                LoadFAQs();
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors du rafraîchissement: {ex.Message}");
            }
        }

        private void btnResetFilter_Click(object sender, EventArgs e)
        {
            // TODO: Réinitialisez uniquement les filtres
            try
            {
                txtSearch.Text = "";
                cmbCategory.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors de la réinitialisation: {ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            MessageBox.Show(message, "Erreur",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void dgvFAQs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

