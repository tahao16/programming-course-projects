﻿namespace OmairyTahaExamenFinal.UI
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelTop = new Panel();
            lblTitle = new Label();
            panelLeft = new Panel();
            grpActions = new GroupBox();
            btnAdd = new Button();
            btnDelete = new Button();
            btnRefresh = new Button();
            grpFilter = new GroupBox();
            label1 = new Label();
            cmbCategory = new ComboBox();
            btnResetFilter = new Button();
            grpSearch = new GroupBox();
            txtSearch = new TextBox();
            btnSearch = new Button();
            panelCenter = new Panel();
            dgvFAQs = new DataGridView();
            statusStrip = new StatusStrip();
            lblStatus = new ToolStripStatusLabel();
            lblCount = new ToolStripStatusLabel();
            panelTop.SuspendLayout();
            panelLeft.SuspendLayout();
            grpActions.SuspendLayout();
            grpFilter.SuspendLayout();
            grpSearch.SuspendLayout();
            panelCenter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvFAQs).BeginInit();
            statusStrip.SuspendLayout();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.BackColor = Color.FromArgb(102, 126, 234);
            panelTop.Controls.Add(lblTitle);
            panelTop.Dock = DockStyle.Top;
            panelTop.Location = new Point(0, 0);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(900, 80);
            panelTop.TabIndex = 2;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Times New Roman", 18F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(111, 23);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(607, 41);
            lblTitle.TabIndex = 0;
            lblTitle.Text = " Gestionnaire de FAQ - Collège LaSalle";
            // 
            // panelLeft
            // 
            panelLeft.Controls.Add(grpActions);
            panelLeft.Controls.Add(grpFilter);
            panelLeft.Controls.Add(grpSearch);
            panelLeft.Dock = DockStyle.Left;
            panelLeft.Location = new Point(0, 80);
            panelLeft.Name = "panelLeft";
            panelLeft.Size = new Size(250, 488);
            panelLeft.TabIndex = 1;
            // 
            // grpActions
            // 
            grpActions.Controls.Add(btnAdd);
            grpActions.Controls.Add(btnDelete);
            grpActions.Controls.Add(btnRefresh);
            grpActions.Dock = DockStyle.Top;
            grpActions.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            grpActions.Location = new Point(0, 250);
            grpActions.Name = "grpActions";
            grpActions.Size = new Size(250, 235);
            grpActions.TabIndex = 0;
            grpActions.TabStop = false;
            grpActions.Text = " Actions";
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.Navy;
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(6, 30);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(238, 62);
            btnAdd.TabIndex = 0;
            btnAdd.Text = " Ajouter FAQ";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(192, 64, 0);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(10, 98);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(234, 69);
            btnDelete.TabIndex = 1;
            btnDelete.Text = " Supprimer";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.Gray;
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Location = new Point(12, 173);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(232, 56);
            btnRefresh.TabIndex = 2;
            btnRefresh.Text = " Rafraîchir";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // grpFilter
            // 
            grpFilter.Controls.Add(label1);
            grpFilter.Controls.Add(cmbCategory);
            grpFilter.Controls.Add(btnResetFilter);
            grpFilter.Dock = DockStyle.Top;
            grpFilter.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            grpFilter.Location = new Point(0, 120);
            grpFilter.Name = "grpFilter";
            grpFilter.Size = new Size(250, 130);
            grpFilter.TabIndex = 1;
            grpFilter.TabStop = false;
            grpFilter.Text = "📂 Filtre";
            // 
            // label1
            // 
            label1.Location = new Point(10, 30);
            label1.Name = "label1";
            label1.Size = new Size(100, 23);
            label1.TabIndex = 0;
            label1.Text = "Catégorie:";
            // 
            // cmbCategory
            // 
            cmbCategory.Location = new Point(10, 55);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(220, 31);
            cmbCategory.TabIndex = 1;
            cmbCategory.SelectedIndexChanged += cmbCategory_SelectedIndexChanged;
            // 
            // btnResetFilter
            // 
            btnResetFilter.Location = new Point(10, 85);
            btnResetFilter.Name = "btnResetFilter";
            btnResetFilter.Size = new Size(129, 39);
            btnResetFilter.TabIndex = 2;
            btnResetFilter.Text = "Réinitialiser";
            btnResetFilter.Click += btnResetFilter_Click;
            // 
            // grpSearch
            // 
            grpSearch.Controls.Add(txtSearch);
            grpSearch.Controls.Add(btnSearch);
            grpSearch.Dock = DockStyle.Top;
            grpSearch.Font = new Font("Times New Roman", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            grpSearch.Location = new Point(0, 0);
            grpSearch.Name = "grpSearch";
            grpSearch.Size = new Size(250, 120);
            grpSearch.TabIndex = 2;
            grpSearch.TabStop = false;
            grpSearch.Text = " Recherche";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(10, 30);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(220, 30);
            txtSearch.TabIndex = 0;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(10, 65);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(107, 35);
            btnSearch.TabIndex = 1;
            btnSearch.Text = "Rechercher";
            btnSearch.Click += btnSearch_Click;
            // 
            // panelCenter
            // 
            panelCenter.Controls.Add(dgvFAQs);
            panelCenter.Dock = DockStyle.Fill;
            panelCenter.Location = new Point(250, 80);
            panelCenter.Name = "panelCenter";
            panelCenter.Size = new Size(650, 488);
            panelCenter.TabIndex = 0;
            // 
            // dgvFAQs
            // 
            dgvFAQs.AllowUserToAddRows = false;
            dgvFAQs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvFAQs.ColumnHeadersHeight = 34;
            dgvFAQs.Dock = DockStyle.Fill;
            dgvFAQs.Location = new Point(0, 0);
            dgvFAQs.Name = "dgvFAQs";
            dgvFAQs.ReadOnly = true;
            dgvFAQs.RowHeadersWidth = 62;
            dgvFAQs.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvFAQs.Size = new Size(650, 488);
            dgvFAQs.TabIndex = 0;
            dgvFAQs.CellContentClick += dgvFAQs_CellContentClick;
            // 
            // statusStrip
            // 
            statusStrip.ImageScalingSize = new Size(24, 24);
            statusStrip.Items.AddRange(new ToolStripItem[] { lblStatus, lblCount });
            statusStrip.Location = new Point(0, 568);
            statusStrip.Name = "statusStrip";
            statusStrip.Size = new Size(900, 32);
            statusStrip.TabIndex = 3;
            // 
            // lblStatus
            // 
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(125, 25);
            lblStatus.Text = "Total: 0 FAQ(s)";
            // 
            // lblCount
            // 
            lblCount.Name = "lblCount";
            lblCount.Size = new Size(141, 25);
            lblCount.Text = "Dernière MAJ: --";
            // 
            // MainForm
            // 
            ClientSize = new Size(900, 600);
            Controls.Add(panelCenter);
            Controls.Add(panelLeft);
            Controls.Add(panelTop);
            Controls.Add(statusStrip);
            Name = "MainForm";
            Text = "Gestionnaire de FAQ";
            Load += MainForm_Load;
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelLeft.ResumeLayout(false);
            grpActions.ResumeLayout(false);
            grpFilter.ResumeLayout(false);
            grpSearch.ResumeLayout(false);
            grpSearch.PerformLayout();
            panelCenter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvFAQs).EndInit();
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelTop, panelLeft, panelCenter;
        private Label lblTitle;
        private GroupBox grpSearch, grpFilter, grpActions;
        private TextBox txtSearch;
        private ComboBox cmbCategory;
        private Button btnSearch, btnResetFilter, btnAdd, btnDelete, btnRefresh;
        private DataGridView dgvFAQs;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel lblStatus, lblCount;
        private Label label1;
    }
}
